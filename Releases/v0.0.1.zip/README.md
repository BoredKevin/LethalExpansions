# LethalExpansion
This simple Lethal Company modpack (not to be confused with the Lethal Expansion SDK Mod) offers many client-side QoL changes.
Changes include better scanner, better walkie-talkies, better hotkeys, changes to the ship, and much more!

This modpack is completely CLIENT-SIDE and is fully compatible with vanilla servers.

## CHANGELOG

### v0.0.1
